Scenario:
 Handle COPY Acitivity from Source - Azure Blob Storage , and move data to Sink - Azure Data Lake Storage

Sol:

# SOURCE - AZURE BLOB STORAGE
https://ssadcloudblobstorage.blob.core.windows.net/raw-container/emp.csv

Name of the Blob Storage    :  ssadcloudblobstorage
Name of the Container       :  raw-container
Name of the Object          :  emp.csv


# SINK - AZURE DATA LAKE STORAGE 
Name of the Blob Storage    :  ssadcloudblobstorage
Name of the Container       :  ouputs/output-from-blob
Name of the Object          :  


# LINKED SERIVCE: A Connection String that helps us to Connect with DataStores - Sources/Sinks
# DATASETS : A Named View for the data from Source and to that of Sink
# ACIVITY: Collection of related Tasks
# PIPELINE: Collection of related  Acitivites

PIPELINES -> ACTIVITES -> DATASETS -> LINKED SERVICE
LINKED SERVICES -> DATASETS -> ACITIVIES -> PIPELINE

# LINKED SERIVCE: (Connection String to Connect with DataStores)
Name of the Linked Service (Source) : LS_AzureBlobStorage
Name of the Linked Service (Sink)   : LS_AzureDataLakeStorage

# DATASETS:
Name of the Source DataSet : ds_source_blob_emp
Name of the Sink DataSet   : ds_sink_adls_emp

# ACTIVITY:
Name of the Activity        : activity_source_blob_sink_datalake

# PIPELINE
Name of the Pipeline        : pipeline_cp_source_blob_to_sink_datalake