Scenario:
 Handle Mapping DataFlow Acitivity to join Employee Table to Department Table[Source] and move Transformed data to Sink - Azure Data Lake Storage

Sol:
# SOURCE - AZURE BLOB STORAGE
Name of the Blob            :  ssadcloudblobstorage
Name of the Container       :  raw-container
Name of the Objects         :  emp.csv
Name of the Objects         :  dep.csv


# SINK - AZURE DATA LAKE STORAGE 
Name of the Data Lake Storage :  ssadclouddatalake
Name of the Container         :  ouputs/output-from-dataflow-emp-dep
Name of the Object            :  


# LINKED SERIVCE: A Connection String that helps us to Connect with DataStores - Sources/Sinks
# DATASETS : A Named View for the data from Source and to that of Sink
# ACIVITY: Collection of related Tasks
# PIPELINE: Collection of related  Acitivites

PIPELINES -> ACTIVITES -> DATASETS -> LINKED SERVICE
LINKED SERVICES -> DATASETS -> ACITIVIES -> PIPELINE

# LINKED SERIVCE: (Connection String to Connect with DataStores)
Name of the Linked Service (Source) : LS_AzureBlobStorage
Name of the Linked Service (Sink)   : LS_AzureDataLakeStorage

# DATASETS:
Name of the Source DataSet1 : ds_source_blob_employee
Name of the Source DataSet2 : ds_source_blob_department

Name of the Sink DataSet   : ds_sink_adls_emp_dep

# ACTIVITY:
Name of the Data Flow Activity        : dataflow_employee_with_department

# PIPELINE
Name of the Pipeline                  : pipeline_dataflow_employee_with_department