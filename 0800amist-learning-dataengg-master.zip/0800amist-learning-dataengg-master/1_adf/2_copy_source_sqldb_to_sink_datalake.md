Scenario:
 Handle COPY Acitivity from Source - Azure SQL Databases , and move data to Sink - Azure Data Lake Storage

Sol:

# SOURCE - AZURE SQL DATBASE
Name of the Database        :  empdb
Name of the SQL Server      :  ssadcloudsqlserver
Credentials for SQL Server  :  ssadcloud/Password


# SINK - AZURE DATA LAKE STORAGE 
Name of the Data Lake Storage :  ssadcloudblobstorage
Name of the Container         :  ouputs/output-from-sqldb
Name of the Object            :  


# LINKED SERIVCE: A Connection String that helps us to Connect with DataStores - Sources/Sinks
# DATASETS : A Named View for the data from Source and to that of Sink
# ACIVITY: Collection of related Tasks
# PIPELINE: Collection of related  Acitivites

PIPELINES -> ACTIVITES -> DATASETS -> LINKED SERVICE
LINKED SERVICES -> DATASETS -> ACITIVIES -> PIPELINE

# LINKED SERIVCE: (Connection String to Connect with DataStores)
Name of the Linked Service (Source) : LS_AzureSqlDatabase
Name of the Linked Service (Sink)   : LS_AzureDataLakeStorage

# DATASETS:
Name of the Source DataSet : ds_source_sqldb_emp
Name of the Sink DataSet   : ds_sink_adls_emp2

# ACTIVITY:
Name of the Activity        : activity_source_sqldb_sink_datalake

# PIPELINE
Name of the Pipeline        : pipeline_cp_source_sqldb_to_sink_datalake