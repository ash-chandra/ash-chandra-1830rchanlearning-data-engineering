{
    "EmployeeID": 101,
    "emp_name": "John Smith",
    "emp_designation": "Software Engineer",
    "emp_salary": 75000,
    "emp_department": "IT",
    "emp_join_date": "15-01-2022",
    "emp_location": "New York"

}

{
    "EmployeeID": 102,
    "emp_name": "Jane Doe",
    "emp_designation": "Data Analyst",
    "emp_salary": 60000,
    "emp_department": "Analytics",
    "emp_join_date": "20-08-2021",
    "emp_location": "San Francisco"

}

{
    "EmployeeID": 103,
    "emp_name": "Mike Brown",
    "emp_designation": "Product Manager",
    "emp_salary": 100000,
    "emp_department": "Product",
    "emp_join_date": "10-05-2023",
    "emp_location": "Germany"

}

{
    "EmployeeID": 104,
    "emp_name": "Peter Brown",
    "emp_designation": "Product Lead",
    "emp_salary": 100000,
    "emp_department": "Product",
    "emp_join_date": "10-05-2023",
    "emp_location": "Germany"

}