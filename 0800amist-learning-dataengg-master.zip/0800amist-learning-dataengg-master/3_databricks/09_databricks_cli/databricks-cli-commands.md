1. Create a workspace 
      $ az databricks workspace create --resource-group kumar-rg --name mainws --location eastus --sku premium

2. List a workspace
      $ az databricks workspace list --resource-group kumar-rg -o table

3. Show a workspace
      $ az databricks workspace show --resource-group kumar-rg --name mainws

5. Configure Databricks
      $ databricks configure

6. Create a Cluster:
      $ databricks clusters create --cluster-name maincluster --node-type-id Standard_DS3_v2 --num-workers 1 14.3.x-scala2.12
   
7. Import Notebook Code:   
      $ databricks workspace import-dir ./notebooks/notebook.py /Workspace/Users/iriscloudone@outlook.com/notebook.py

8. Create Databricks Job
      $ databricks jobs submit --json '@.\main_job_query.json'

9. List Databricks Jobs:
      $ databricks jobs list-runs
      $ databricks jobs delete-run <<RUN_ID>>
   
10. Delete Databricks Cluster:
      $ databricks clusters list
      $ databricks cluster delete <cluster-id>

11. Delete the Workspace
      $ az databricks workspace delete --resource-group kumar-rg --name mainws -y

# Note: 
      - Install jq 
            on macOS by using Homebrew with 
                  $ brew install jq
            on Windows by using Chocolatey with (Run as Administrator)
                  $ choco install jq
