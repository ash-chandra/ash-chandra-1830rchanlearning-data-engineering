# Databricks notebook source
user_name = "kumar@vcloudmatesolutions.com"

salesorders_filename = "sales_orders.csv"
products_filename = "products.csv"

salesorders_filePath = (
    "dbfs:/FileStore/shared_uploads/" + user_name + "/" + salesorders_filename
)
products_filePath = (
    "dbfs:/FileStore/shared_uploads/" + user_name + "/" + products_filename
)

# COMMAND ----------

salesordersDF = spark.read.csv(salesorders_filePath, header=True, inferSchema=True)
productsDF = spark.read.csv(products_filePath, header=True, inferSchema=True)

# COMMAND ----------

display(salesordersDF)
display(productsDF)

# COMMAND ----------

display(salesordersDF.isStreaming)
display(productsDF.isStreaming)


# COMMAND ----------

salesordersDF.write.format("parquet").save("/tmp/salesorders", mode="overwrite")
productsDF.write.format("parquet").save("/tmp/products", mode="overwrite")

# COMMAND ----------

salesorders_streamingDF = spark.readStream.schema(salesordersDF.schema)\
                                          .parquet("/tmp/salesorders")
                                           
products_streamingDF = spark.readStream.schema(productsDF.schema)\
                                          .parquet("/tmp/products")

# COMMAND ----------

display(salesorders_streamingDF.isStreaming)
display(products_streamingDF.isStreaming)

# COMMAND ----------

salesorder_product_joinedDF = salesorders_streamingDF.join(products_streamingDF,'product_id')

# COMMAND ----------

tableName = 'salesorders_tbl'
checkpointLocation = '/tmp/_checkpoint'

# COMMAND ----------

query = (
    salesorder_product_joinedDF.writeStream.toTable(
                tableName=tableName,
                outputMode="append", 
                checkpointLocation=checkpointLocation
                )
)

# COMMAND ----------

query.stop()

# COMMAND ----------

display(spark.sql('SELECT SUM(total_amount) AS TotalSalesAmount FROM salesorders_tbl'))
display(spark.sql('SELECT product_id,SUM(quantity) AS ItemsSoldQty FROM salesorders_tbl GROUP BY product_id'))
