# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: center;">
# MAGIC   <img src="https://www.vcloudmatesolutions.com/assets/img/vcm3.jpg">
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC #### Load Parquet Datasets from Azure Data Lake Storage Gen2 Using SAS Token

# COMMAND ----------

# Path for Parquet Data Set
# https://ssadcloudazdatalake.blob.core.windows.net/data/green_tripdata_2023-01.parquet

# COMMAND ----------

# MAGIC %md
# MAGIC ### Using ABFSS

# COMMAND ----------

storage_account_name="ssadcloudazdatalake"
storage_container_name="data"
greentaxi_storge_relative_path="green_tripdata_2023-01.parquet"
storage_sas_key = "<<SAS_KEY_FROM_AZURE_STORAGE>>"

# COMMAND ----------

print(storage_account_name)
print(storage_container_name)
print(greentaxi_storge_relative_path)
print(storage_sas_key)

# COMMAND ----------

spark.conf.set(
  f"fs.azure.account.key.{storage_account_name}.dfs.core.windows.net",
  f"{storage_sas_key}"
)

# COMMAND ----------

greentaxi_abfss_path =f"abfss://%s@%s.dfs.core.windows.net/%s" %(storage_container_name,storage_account_name,greentaxi_storge_relative_path)

# COMMAND ----------

print(greentaxi_abfss_path)

# COMMAND ----------

dbutils.fs.ls(greentaxi_abfss_path)

# COMMAND ----------

greentaxiDF = spark.read.parquet(greentaxi_abfss_path)

# COMMAND ----------

display(greentaxiDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Register DataFrame into Temp Views

# COMMAND ----------

greentaxiDF.createOrReplaceTempView('greentaxiView')

# COMMAND ----------

min_fareamountQuery = "SELECT min(fare_amount) AS MinFareAmount FROM greentaxiView"
max_fareamountQuery = "SELECT max(fare_amount) AS MaxFareAmount FROM greentaxiView"
avg_fareamountQuery = "SELECT avg(fare_amount) AS AvgFareAmount FROM greentaxiView"

# COMMAND ----------

min_fareamountQueryResults = spark.sql(min_fareamountQuery)
display(min_fareamountQueryResults)

max_fareamountQueryResults = spark.sql(max_fareamountQuery)
display(max_fareamountQueryResults)

avg_fareamountQueryResults = spark.sql(avg_fareamountQuery)
display(avg_fareamountQueryResults)

# COMMAND ----------

# List Created Views
spark.catalog.listTables()

# COMMAND ----------

# To Drop Created View
spark.catalog.dropTempView('greentaxiview')

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

# MAGIC %md
# MAGIC © 2024 VCLOUDMATE SOLUTIONS. All Rights Reserved
# MAGIC - For Educational Purpose only
# MAGIC - Any Logos and Trademarks used belong to their respective Owners
# MAGIC
