###################################################################
# Deploy a workspace with the Azure CLI
###################################################################
1. Use Azure CLI
   $ az --version

2. Login into Azure CLI
   $ az login

3. Upgrade Azure CLI to Azure Databricks 
   $ az extension add --name databricks

4. Create your own Resource Group
   $ az group create --name databricks-quickstart --location eastus

5. List Azure Databricks Workspaces
   $ az databricks workspace list

6. Create Azure Databricks Workspace
   $ az databricks workspace create --resource-group databricks-quickstart --name databricksbycli --location eastus  --sku standard

7. Show the workspace.
   $ az databricks workspace show

8. Update the Workspace
   $ az databricks workspace update --resource-group MyResourceGroup --name MyWorkspace --tags key1=value1 key2=value2

9. Delete the Workspace
   $ az databricks workspace delete --resource-group databricks-quickstart --name databricksbycli